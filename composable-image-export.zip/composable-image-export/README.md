# compose-image-export
Android Compose: how to export a Composable as an image. 3 ways.
Show how View.draw is not suitable for exporting Composables that utilize pixel blending.
